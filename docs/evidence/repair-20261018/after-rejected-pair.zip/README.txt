SKYSHIFT saved comparison. Scientific approval PENDING.
Original FITS and calibration URLs/hashes are in manifest.json; this compact packet references them.
Run: skyshift reconstruct comparison.zip --output new-folder
Archive access is required when original inputs are absent. If upstream bytes changed, use the self-contained review packet.
Display extensions (log, palette, interpolation, wipe) are in visualization.json and restored by this browser; Python reconstructs scientific arrays and core manifest settings. Notes are user observations, not confirmed discoveries.
