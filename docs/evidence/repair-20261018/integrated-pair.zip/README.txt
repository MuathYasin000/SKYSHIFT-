SKYSHIFT comparison investigation. Scientific approval PENDING.
Original FITS and calibration references and hashes are in manifest.json. Prepared common-grid FITS, masks, diagnostics, notes and display settings are included.
Reconstruct: skyshift reconstruct comparison.zip --output new-folder
Original inputs require archive access if absent locally. This is a reference packet, not a self-contained original-data review packet. Display extensions are in visualization.json. Questions are hypotheses, not discoveries.
